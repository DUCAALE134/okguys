/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zoo;

/**
 *
 * @author khalid
 */
   public class Zoo{

    public static void main(String[] args) {
        // Create instances of each animal
        Animal lion = new Lion("Leo", 5);
        Animal elephant = new Elephant("Dumbo", 10);
        Animal Monkey = new Monkey("George", 3);

        // Demonstrate method overriding
        lion.makeSound();
        lion.eat();

        elephant.makeSound();
        elephant.eat();
        Monkey.makeSound();
        Monkey.eat();

        // Demonstrate polymorphism with overloaded methods
        lion.makeSound(3);
        elephant.eat("fruits");
        Monkey.makeSound(2);
    }
}

