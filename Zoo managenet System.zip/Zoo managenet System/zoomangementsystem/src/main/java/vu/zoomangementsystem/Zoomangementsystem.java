/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package vu.zoomangementsystem;

/**
 *
 * @author khalid
 */
public class Zoomangementsystem {

    public static void main(String[] args) {
        System.out.println("Enter your name ");
    }
}
